/**
 * @jest-environment jsdom
 */

global.HTTP_VERSION = 2;

require('./main');
