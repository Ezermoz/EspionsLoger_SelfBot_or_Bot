window.fetch = require('node-fetch');
window.URLSearchParams = require('url').URLSearchParams;
window.FormData = require('form-data');

require('../main');
